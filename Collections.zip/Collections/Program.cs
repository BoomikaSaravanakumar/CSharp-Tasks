﻿using System;

namespace Interface_Exception
{
    internal class Program
    {
        static void Main(string[] args)
        {
            CourierService courierService = new CourierService();

            // Adding a courier staff
            Employee newStaff = new Employee(55, "John", "john@example.com", "9876543210", "Delivery Agent", 30000);
            int staffId = courierService.AddStaff(newStaff);
            Console.WriteLine($"New Courier Staff Added: ID {staffId}");

            // Placing an order
            Courier newCourier = new Courier(92, "Alice", "123 Main St", "Bob", "456 Oak ,Chennai", 5.5, "Processing", "TkU5674", DateTime.Now.AddDays(3), staffId);
            string trackingNumber = courierService.CourierOrder(newCourier);
            Console.WriteLine($"Order Placed. Tracking Number: {trackingNumber}");

            // Getting order status
            string status = courierService.GetStatus(trackingNumber);
            Console.WriteLine($"Order Status: {status}");

            // Canceling an order
            bool isCanceled = courierService.OrderCancelled(trackingNumber);
            Console.WriteLine($"Order Canceled: {isCanceled}");


            try
            {
                //  invalid tracking number
                string Status = courierService.GetStatus(trackingNumber);
                Console.WriteLine($"Tracking Status: {status}");
            }
            catch (TrackingNumberNotFoundException ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }

            try
            {
                //  invalid employee ID
                courierService.VerifyEmployeeId(staffId);
            }
            catch (InvalidEmployeeIdException ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
            finally
            {
                Console.WriteLine("Execution completed.");
            }
        }

    }
    }
