﻿using System;
using System.Collections.Generic;

namespace Interface_Exception
{
    public class CourierService : ICourierService, ICourierAdminService
    {
        private List<Courier> couriers = new List<Courier>();
        private List<Employee> employees = new List<Employee>();

        public string CourierOrder(Courier courierObj)  
        {
            couriers.Add(courierObj);
            return courierObj.TrackingNumber;
        }

        public string GetStatus(string trackingNumber)
        {
            var order = couriers.Find(c => c.TrackingNumber == trackingNumber);
            if (order == null)
            {
                throw new TrackingNumberNotFoundException($"Tracking number {trackingNumber} not found.");
            }
            return order.Status;
        }

        public bool OrderCancelled(string trackingNumber)
        {
            var order = couriers.Find(c => c.TrackingNumber == trackingNumber);
            if (order != null && order.Status == "Yet to Transit")
            {
                couriers.Remove(order);
                return true;
            }
            return false;
        }

        public List<Courier> GetOrderAssigned(int staffID)
        {
            return couriers.FindAll(c => c.AssignedEmployeeID == staffID).ToList();
        }

        public int AddStaff(Employee obj)
        {
            obj.EmployeeID = employees.Count + 1;
            employees.Add(obj);
            return obj.EmployeeID;
        }
        public void VerifyEmployeeId(int employeeId)
        {
            var employee = employees.Find(e => e.EmployeeID == employeeId);
            if (employee == null)
            {
                throw new InvalidEmployeeIdException($"Employee ID {employeeId} does not exist.");
            }
        }
    }
}
