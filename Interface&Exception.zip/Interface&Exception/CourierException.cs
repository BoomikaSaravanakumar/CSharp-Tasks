﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interface_Exception
{
    public class TrackingNumberNotFoundException : Exception
    {
        public TrackingNumberNotFoundException(string message) : base(message) { }
    }

    public class InvalidEmployeeIdException : Exception
    {
        public InvalidEmployeeIdException(string message) : base(message) { }
    }

}
