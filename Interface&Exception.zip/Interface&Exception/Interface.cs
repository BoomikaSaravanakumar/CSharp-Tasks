﻿using System.Collections.Generic;

namespace Interface_Exception
{
    public interface ICourierService
    {
        string CourierOrder(Courier courierObj);  
        string GetStatus(string trackingNumber);
        bool OrderCancelled(string trackingNumber);
        List<Courier> GetOrderAssigned(int staffID);
    }

    public interface ICourierAdminService
    {
        int AddStaff(Employee obj);
    }
}
