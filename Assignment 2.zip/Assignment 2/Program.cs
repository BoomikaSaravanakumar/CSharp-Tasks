﻿using System.Text.RegularExpressions;

namespace Assignment_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
           
                CourierCompany company = new CourierCompany("Ecomm Delivery");

               
                User user = new User(1, "Ravei", "ravei@example.com", "ravei12", "8956743829", "123 Gandhi St,Chennai");
                User user2 = new User(2, "Hari", "hari@example.com", "hari01", "7845637729", "98 Gcross,vellore");
                
                Courier courier1 = new Courier(1, "Ravei", "123 Gandhi St,chennai", "Joe", "456 Nehru St,coimbatore", 5.5, "Processing", "TRK123", DateTime.Now.AddDays(3), user.UserID);
                company.AddCourier(courier1);
                Courier courier2 = new Courier(2, "Hari", "98 Gcross,vellore", "Bob", "853 Tea St,Ooty", 6.8, "Delivered", "TRK543", DateTime.Now, user2.UserID);
                company.AddCourier(courier2);

                Employee employee1 = new Employee(1, "Jabel", "jabel@example.com", "9876647210", "Delivery Agent", 30000);
                company.AddEmployees(employee1);

              
                Location location1 = new Location(1, "WaterHouse", "789 Oak St,Bangalore");
                company.AddLocations(location1);

                Payment payment1 = new Payment(1, courier1.CourierID, 100.50, DateTime.Now);


                
                Console.WriteLine("\n---------\n");

                // 1. Check Order Status
                company.CheckingOrderStatus(courier1);

                // 2. Categorize Parcel
                Console.WriteLine($"Parcel Weight Category: {company.CategorizingParcel(courier1.Weight)}");
                Console.WriteLine($"Parcel Weight Category: {company.CategorizingParcel(courier2.Weight)}");

                // 3. Authenticate User
                List<User> users = new List<User> { user };
                Console.WriteLine($"Authentication Success: {company.AuthenticatedUser("ravei@example.com", "ravei12", users)}");
                List<User> users2 = new List<User> { user2 };
                Console.WriteLine($"Authentication Success: {company.AuthenticatedUser("hari@example.com", "hari01", users2)}");

                // 4. Assign Couriers
                company.AssigningCourier(company.CourierDetails);

                // 5. Display Customer Orders
                company.DisplayOrders(user.UserID, company.CourierDetails);
                company.DisplayOrders(user2.UserID, company.CourierDetails);
              
                // 6. Track Real-Time Courier
                company.TrackingCourier(courier1);
                company.TrackingCourier(courier2);

               // 7. Tracking History (Array)
               string[] trackingHistory = { "Dispatched", "In Transit", "Out for Delivery", "Delivered" };
                Console.WriteLine($"Tracking Status: {trackingHistory.Last()}");

                // 8. Find Nearest Courier
                Courier nearestCourier = company.FindNearCourier(company.CourierDetails);
                Console.WriteLine($"Nearest Available Courier: {nearestCourier.CourierID}");

                // 9. Parcel Tracking (2D Array)
                Console.WriteLine($"Tracking Info: {company.GetStatus("TRK123")}");
                Console.WriteLine($"Tracking Info: {company.GetStatus("TRK543")}");


               // 10. Validate Customer Data
                Console.WriteLine($"Is Valid Name: {company.ValidatingData("Ravei", "name")}");
                Console.WriteLine($"Is Valid Phone: {company.ValidatingData("8956743829", "phone")}");

                // 11. Address Formatting
                Console.WriteLine($"Formatted Address: {company.FormatedAddress("123 Gandhi st,chennai", "new york", "ny", "10001")}");

                // 12. Order Confirmation Email
                company.SendingConfirmationEmail(user, courier1);
                company.SendingConfirmationEmail(user2, courier2);

                // 13. Calculate Shipping Cost
                Console.WriteLine($"Shipping Cost: ${company.CalculatingShippingCost("Warehouse 1", "456 Nehru St,coimbatore", courier1.Weight)}");

                // 14. Generate Secure Password
                Console.WriteLine($"Generated Password: {company.GenerateUserPassword(10)}");

                // 15. Find Similar Addresses
                List<string> addresses = new List<string> { "123 Gandhi St,chennai", "456 Nehru St,coimbatore", "789 Oak St,Bangalore", "123 Maple St" };
                var similarAddresses = company.FindingSimilarAddresses("123", addresses);
                Console.WriteLine("Similar Addresses: " + string.Join(", ", similarAddresses));

                Console.WriteLine("Press any key to exit...");
                Console.ReadKey();
            }

        }
    }

    
