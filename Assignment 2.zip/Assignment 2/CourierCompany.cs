﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Assignment_2
{
    internal class CourierCompany
    {
        public string CompanyName { get; set; }
        public Courier[] CourierDetails { get; set; }
        public Employee[] EmployeeDetails { get; set; }
        public Location[] LocationDetails { get; set; }

        public CourierCompany(string companyName)
        {
            CompanyName = companyName;
            CourierDetails = new Courier[0];  // Initialize with provided couriers
            EmployeeDetails = new Employee[0]; // Empty array initially
            LocationDetails = new Location[0]; // Empty array initially
        }

        // Method to add employees using params
        public void AddEmployees(params Employee[] employees)
        {
            EmployeeDetails = employees;  // Assign the given employees
        }

        // Method to add locations using params
        public void AddLocations(params Location[] locations)
        {
            LocationDetails = locations;  // Assign the given locations
        }
        //Method to add Courier
        public void AddCourier(params Courier[] couriers)
        {
            CourierDetails = couriers;  // Assign the given employees
        }


        //question 1:
        public void CheckingOrderStatus(Courier courier)
        {
            if (courier.Status == "Delivered")
                Console.WriteLine("Order has been delivered.");
            else if (courier.Status == "Processing")
                Console.WriteLine("Order is being processed.");
            else
                Console.WriteLine("Order is cancelled.");
        }
        //question 2:
        public string CategorizingParcel(double weight)
        {
            switch (weight)
            {
                case < 2:
                    return "Light";
                case <= 5:
                    return "Medium";
                default:
                    return "Heavy";
            }
        }
        //question 3:
        public bool AuthenticatedUser(string email, string password, List<User> users)
        {
            foreach (var user in users)
            {
                if (user.Email == email && user.Password == password)
                    return true;
            }
            return false;
        }
        //question 4:
        public void AssigningCourier(params Courier[] couriers)
        {
            foreach (var courier in couriers)
            {
                Console.WriteLine($"Assigning Courier {courier.CourierID}");
            }
        }
        //question 5:
        public void DisplayOrders(int userId, params Courier[] couriers)
        {
            for (int i = 0; i < couriers.Length; i++)
            {
                if (couriers[i].UserID == userId)
                    Console.WriteLine($"Order {couriers[i].CourierID} for User {userId}");
            }
        }
        //queestion 6:
        public void TrackingCourier(Courier courier)
        {
            while (courier.Status != "Delivered")
            {
                Console.WriteLine($"Tracking {courier.TrackingNumber}: Status - {courier.Status}");
                courier.Status = "Delivered"; // Simulate update
            }
        }
        //question 7:
        string[] trackingHistory = { "Dispatched", "In Transit", "Out for Delivery", "Delivered" };
        //question 8:
        public Courier FindNearCourier(params Courier[] couriers)
        {
            return couriers.OrderBy(c => c.Weight).FirstOrDefault();
        }
        //question 9:
        public string GetStatus(string trackingNumber)
        {
            string[,] trackingData = {
            { "TRK123", "In Transit" },
            { "TRK456", "Out for Delivery" }
        };
            for (int i = 0; i < trackingData.GetLength(0); i++)
                if (trackingData[i, 0] == trackingNumber)
                    return trackingData[i, 1];
            return "Not Found";
        }
        //question 10:
        public bool ValidatingData(string data, string type)
        {
            return type switch
            {
                "name" => data.All(char.IsLetter),
                "phone" => Regex.IsMatch(data, @"^\d{3}-\d{3}-\d{4}$"),
                _ => false
            };
        }
        //question 11:
        public string FormatedAddress(string street, string city, string state, string zip)
        {
            return $"{char.ToUpper(street[0]) + street.Substring(1)}, {char.ToUpper(city[0]) + city.Substring(1)}, {state.ToUpper()} {zip}";
        }
        //question 12:
        public void SendingConfirmationEmail(User user, Courier courier)
        {
            Console.WriteLine($"Dear {user.UserName}, Your order {courier.TrackingNumber} will be delivered to {user.Address} on {courier.DeliveryDate}.");
        }
        //question 13:
        public double CalculatingShippingCost(string source, string destination, double weight)
        {
            return weight * new Random().Next(10, 100) * 0.5;
        }
        //question 14:
        public string GenerateUserPassword(int length)
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%";
            return new string(Enumerable.Repeat(chars, length).Select(s => s[new Random().Next(s.Length)]).ToArray());
        }
        //question 15:
        public  List<string> FindingSimilarAddresses(string query, List<string> addresses)
        {
            return addresses.Where(a => a.Contains(query, StringComparison.OrdinalIgnoreCase)).ToList();
        }

    }


}
