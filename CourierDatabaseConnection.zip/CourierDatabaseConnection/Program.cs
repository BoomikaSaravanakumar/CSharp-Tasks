﻿using CourierDatabaseConnection.DAO;
using CourierDatabaseConnection.Entity;

namespace CourierDatabaseConnection
{
    internal class Program
    {
        static void Main(string[] args)
        {
            CourierServiceDb db = new CourierServiceDb();
            UserInterface ui = new UserInterface();

            //GetRevenue=============================================
            try
            {
                decimal revenue = db.GetRevenueReport();
                Console.WriteLine(revenue);
            }

            //GetShipmentStatus==============================================
            //var status = db.GenerateShipmentStatusReport();
            //foreach (var item in status)
            //{
            //    Console.WriteLine($"{status.Keys},{status.Values}");
            //}

            //UpdateCost============================================
            //try
            //{
            //    int id = ui.GetServiceId();
            //    decimal cost = ui.GetCost();
            //    int i = db.UpdateCourierCost(id, cost);
            //    Console.WriteLine(i);
            //}



            //GetCourierById================================================================
            //try
            //{
            //    int id = ui.GetServiceId();
            //    CourierServices sc = db.GetCourierById(id);
            //    Console.WriteLine(sc);

            //}


            //Deleting a courier========================================================

            //try
            //{
            //    int i=ui.GetServiceId();
            //    int res=db.DeleteCourier(i);
            //    Console.WriteLine(res);
            //}

            //AddProduct===================================================
            //try
            //{
            //    CourierServices cs = new CourierServices();
            //    cs.ServiceId = ui.GetServiceId();
            //    cs.ServiceName = ui.GetServiceName();
            //    cs.CourierId = ui.GetCourierId();
            //    cs.Cost = ui.GetCost();
            //    db.AddCourier(cs);

            //}


            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }
        static void Display(List<CourierServices> Couriers)
        {
            foreach (CourierServices cs1 in Couriers)
            {
                Console.WriteLine(cs1);
            }
        }
    }
}
